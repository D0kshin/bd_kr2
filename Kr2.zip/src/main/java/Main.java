import db.SchoolDB;

import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Locale;


public class Main {
    public static void main(String[] args) {


    }
}