rootProject.name = "BdKr2"

